﻿namespace Infraestrutura.Autenticacao
{
    public class ConfigsToken
    {
        public string Audience { get; set; }
        public string Issuer { get; set; }
        public int Seconds { get; set; }
    }
}
