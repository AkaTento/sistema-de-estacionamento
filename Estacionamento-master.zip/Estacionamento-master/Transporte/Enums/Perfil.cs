﻿namespace Transporte.Enums
{
    public enum Perfil
    {
        Administrador = 1,
        Cliente = 2
    }
}
