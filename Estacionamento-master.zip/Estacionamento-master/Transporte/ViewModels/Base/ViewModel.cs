﻿namespace Transporte.ViewModels.Base
{
    public abstract class ViewModel
    {
        public int Id { get; set; }
    }
}
