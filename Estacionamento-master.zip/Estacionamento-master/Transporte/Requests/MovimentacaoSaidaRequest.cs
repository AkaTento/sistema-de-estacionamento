﻿namespace Transporte.Requests
{
    public class MovimentacaoSaidaRequest
    {
        public int Id { get; set; }
        public string SaiuEm { get; set; }
    }
}
