﻿namespace Transporte.Requests.Base
{
    public class Request
    {
        public int RegistrosPorPagina { get; set; }
        public int PaginaAtual { get; set; }
    }
}
